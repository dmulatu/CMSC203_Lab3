package Lab3GradeBook;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

public class GradebookTester {
    private GradeBook grade1;
    private GradeBook grade2;

    @BeforeEach
    public void setUp() {
        grade1 = new GradeBook(5);
        grade2 = new GradeBook(5);

        grade1.addScore(50);
        grade1.addScore(75);

        grade2.addScore(30);
        grade2.addScore(90);
        grade2.addScore(60);
    }

    @AfterEach
    public void tearDown() {
        grade1 = null;
        grade2 = null;
    }

    @Test
    public void testAddScore() {
        assertEquals(2, grade1.getScoreSize());
        assertEquals(3, grade2.getScoreSize());
    }

    @Test
    public void testSum() {
        assertEquals(125, grade1.sum(), 0.0001);
        assertEquals(180, grade2.sum(), 0.0001);
    }

    @Test
    public void testMinimum() {
        assertEquals(50, grade1.minimum(), 0.0001);
        assertEquals(30, grade2.minimum(), 0.0001);
    }

    @Test
    public void testFinalScore() {
        assertEquals(75, grade1.finalScore(), 0.0001);
        assertEquals(150, grade2.finalScore(), 0.0001);
    }
}
